import sys

from PyQt5.QtCore import pyqtSlot, QTimer, Qt, QCoreApplication
from PyQt5.QtGui import QPainter, QPen, QColor
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton

# 참고 링크: https://blog.jiktong.kr/2246
# http://www.gisdeveloper.co.kr/?p=8360


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.pos_x = int(self.width() / 2)
        # self.direction = 1
        # self.speed = 0

    def initUI(self):
        # 윈도우 설정
        self.setGeometry(500, 200, 500, 500)  # x, y, w, h
        self.setWindowTitle('지하철 노선도')

        # Timer 설정
        # self.timer = QTimer(self)
        # self.timer.start(int(1000/30))
        # self.timer.timeout.connect(self.timeout_run)

        # 창닫기 버튼
        # btn = QPushButton('Quit', self)
        # btn.move(int(self.width() / 2 - 40), int(self.height() / 2 + 200))
        # btn.resize(btn.sizeHint())
        # btn.clicked.connect(QCoreApplication.instance().quit)

    def paintEvent(self, e):
        qp = QPainter()
        qp.begin(self)
        self.draw_Lines(qp)
        self.draw_point(qp)
        qp.end()

    def draw_point(self, qp):  # 현재 위치를 포인트로 표시
        qp.setBrush(QColor(255, 85, 105))  # RGB Red
        # qp.drawRect(400, 35, 12, 12)      # x, y, 크기

        line8 = ['암사', '천호', '강동구청', '몽촌토성', '잠실', '석촌',
                 '산성', '복정', '장지', '문정', '가락시장', '송파',
                 '남한산성입구', '단대오거리', '신흥', '수진', '모란']
        # 8호선 기준. 노선도의 각 면 별로 역들 정리

        now_station = '남한산성입구'
        now_stationNum = -1
        for i in range(len(line8)):
            if now_station == line8[i]:
                now_stationNum = i  # line2, 즉 역들 리스트 안에 now_station이 있을 경우 해당 인덱스를 now_stationNum에 저장
                # 리스트 내에 없을 경우, now_stationNum은 그대로 -1이고 노선도에 표시가 안 됨

        global x  # draw_Lines에서도 x 쓸 거라서.. 일단 전역변수 해놓음
        x = 10

        # qp.drawRect(x좌표, y좌표, 포인트의 크기(x, y) => 포인트 생성
        # int() 넣는 이유: 실수형으로 넣을 경우 경고문이 떠서
        if 0 <= now_stationNum < 6:
            qp.drawRect(int(10 + 6 * now_stationNum) * x, int(14.5 * x), 12, 12)
        elif 6 <= now_stationNum < 12:
            qp.drawRect(int(10 + 6 * (now_stationNum - 6)) * x, int(24.5 * x), 12, 12)
        elif 12 <= now_stationNum <= 16:
            qp.drawRect(int(11 + 7 * (now_stationNum - 12)) * x, int(34.5 * x), 12, 12)

        # print(now_stationNum)

    def draw_Lines(self, qp):  # 3호선
        red = Qt.red
        linePen = QPen(red, 3.5, Qt.SolidLine)
        qp.setPen(linePen)

        x = 10  # 크기조정하면 위치가 이상해짐.....수정필요
        qp.drawLine(6 * x, 15 * x, 44 * x, 15 * x)  # x1, y1, x2, y2  # 1행
        qp.drawLine(6 * x, 25 * x, 44 * x, 25 * x)  # 2행    # 가로 길이 = 38 * x
        qp.drawLine(6 * x, 35 * x, 44 * x, 35 * x)  # 3행
        qp.drawLine(44 * x, 15 * x, 44 * x, 25 * x)  # 1열    # 세로 길이 = 10 * x
        qp.drawLine(6 * x, 25 * x, 6 * x, 35 * x)  # 2열
    # def timeout_run(self):
    #     if self.pos_x < 0 or self.pos_x > self.width() - 8:
    #         self.direction *= -1
    #     self.pos_x = self.pos_x + (self.direction * self.speed)
    #     # print(self.pos_x, self.width())
    #     self.update()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())