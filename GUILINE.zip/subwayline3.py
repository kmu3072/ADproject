import sys

from PyQt5.QtCore import pyqtSlot, QTimer, Qt, QCoreApplication
from PyQt5.QtGui import QPainter, QPen, QColor
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton

# 참고 링크: https://blog.jiktong.kr/2246
# http://www.gisdeveloper.co.kr/?p=8360


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.pos_x = int(self.width() / 2)
        # self.direction = 1
        # self.speed = 0

    def initUI(self):
        # 윈도우 설정
        self.setGeometry(500, 200, 500, 500)  # x, y, w, h
        self.setWindowTitle('지하철 노선도')

        # Timer 설정
        # self.timer = QTimer(self)
        # self.timer.start(int(1000/30))
        # self.timer.timeout.connect(self.timeout_run)

        # 창닫기 버튼
        # btn = QPushButton('Quit', self)
        # btn.move(int(self.width() / 2 - 40), int(self.height() / 2 + 200))
        # btn.resize(btn.sizeHint())
        # btn.clicked.connect(QCoreApplication.instance().quit)

    def paintEvent(self, e):
        qp = QPainter()
        qp.begin(self)
        self.draw_Lines(qp)
        self.draw_point(qp)
        qp.end()

    def draw_point(self, qp):  # 현재 위치를 포인트로 표시
        qp.setBrush(QColor(255, 85, 105))  # RGB Red
        # qp.drawRect(400, 35, 12, 12)      # x, y, 크기

        line3 = ['대화', '주엽', '정발산', '마두', '백석', '대곡', '화정', '원당', '원흥', '삼송', '지축', '구파발',
                 '충무로', '을지로3가', '종로3가', '안국', '경복궁', '독립문', '무악재', '홍제', '녹번', '불광', '연신내',
                 '동대입구', '약수', '금호', '옥수', '압구정', '신사', '잠원', '고속터미널', '교대', '남부터미널', '양재',
                 '오금', '경찰병원', '가락시장', '수서', '일원', '대청', '학여울', '대치', '도곡', '매봉']
        # 2호선 기준. 노선도의 각 면 별로 역들 정리

        now_station = '을지로3가'
        now_stationNum = -1
        for i in range(len(line3)):
            if now_station == line3[i]:
                now_stationNum = i  # line2, 즉 역들 리스트 안에 now_station이 있을 경우 해당 인덱스를 now_stationNum에 저장
                # 리스트 내에 없을 경우, now_stationNum은 그대로 -1이고 노선도에 표시가 안 됨

        global x  # draw_Lines에서도 x 쓸 거라서.. 일단 전역변수 해놓음
        x = 10

        # qp.drawRect(x좌표, y좌표, 포인트의 크기(x, y) => 포인트 생성
        # int() 넣는 이유: 실수형으로 넣을 경우 경고문이 떠서
        if 0 <= now_stationNum < 12:
            qp.drawRect(int(8 + 2.95 * now_stationNum) * x, int(9.5 * x), 12, 12)
        elif 12 <= now_stationNum < 23:
            qp.drawRect(int(8 + 3.25 * (now_stationNum - 12)) * x, int(19.5 * x), 12, 12)
        elif 23 <= now_stationNum < 34:
            qp.drawRect(int(8 + 3.25 * (now_stationNum - 23)) * x, int(29.5 * x), 12, 12)
        elif 34 <= now_stationNum <= 43:
            qp.drawRect(int(8 + 3.55 * (now_stationNum - 34)) * x, int(39.5 * x), 12, 12)

        # print(now_stationNum)

    def draw_Lines(self, qp):  # 3호선
        darkRed = Qt.darkRed
        linePen = QPen(darkRed, 3.5, Qt.SolidLine)
        qp.setPen(linePen)

        x = 10  # 크기조정하면 위치가 이상해짐.....수정필요
        qp.drawLine(6 * x, 10 * x, 44 * x, 10 * x)  # x1, y1, x2, y2  # 1행
        qp.drawLine(6 * x, 20 * x, 44 * x, 20 * x)  # 2행    # 가로 길이 = 38 * x
        qp.drawLine(6 * x, 30 * x, 44 * x, 30 * x)  # 3행
        qp.drawLine(6 * x, 40 * x, 44 * x, 40 * x)  # 4행
        qp.drawLine(44 * x, 10 * x, 44 * x, 20 * x)  # 1열    # 세로 길이 = 10 * x
        qp.drawLine(6 * x, 20 * x, 6 * x, 30 * x)  # 2열
        qp.drawLine(44 * x, 30 * x, 44 * x, 40 * x)  # 3열

    # def timeout_run(self):
    #     if self.pos_x < 0 or self.pos_x > self.width() - 8:
    #         self.direction *= -1
    #     self.pos_x = self.pos_x + (self.direction * self.speed)
    #     # print(self.pos_x, self.width())
    #     self.update()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())