import sys

from PyQt5.QtCore import pyqtSlot, QTimer, Qt, QCoreApplication
from PyQt5.QtGui import QPainter, QPen, QColor
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton

# 참고 링크: https://blog.jiktong.kr/2246
# http://www.gisdeveloper.co.kr/?p=8360


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.pos_x = int(self.width() / 2)
        # self.direction = 1
        # self.speed = 0

    def initUI(self):
        # 윈도우 설정
        self.setGeometry(500, 200, 500, 500)  # x, y, w, h
        self.setWindowTitle('지하철 노선도')

        # Timer 설정
        # self.timer = QTimer(self)
        # self.timer.start(int(1000/30))
        # self.timer.timeout.connect(self.timeout_run)

        # 창닫기 버튼
        # btn = QPushButton('Quit', self)
        # btn.move(int(self.width() / 2 - 40), int(self.height() / 2 + 200))
        # btn.resize(btn.sizeHint())
        # btn.clicked.connect(QCoreApplication.instance().quit)

    def paintEvent(self, e):
        qp = QPainter()
        qp.begin(self)
        self.draw_Lines(qp)
        self.draw_point(qp)
        qp.end()

    def draw_point(self, qp):  # 현재 위치를 포인트로 표시
        qp.setBrush(QColor(255, 85, 105))  # RGB Red
        # qp.drawRect(400, 35, 12, 12)      # x, y, 크기

        line4 = ['당고개', '상계', '노원', '창동', '쌍문', '수유', '미아', '미아사거리', '길음', '성신여대입구', '한성대입구',
                 '동작', '이촌', '신용산', '삼각지', '숙대입구', '서울역', '회현', '명동', '충무로', '동대문역사문화공원', '동대문', '혜화',
                 '총신대입구', '사당', '남태령', '선바위', '경마공원', '대공원', '과천', '정부과천청사', '인덕원', '평촌', '범계', '금정', '산본',
                 '오이도', '정왕', '신길온천', '안산', '초지', '고잔', '중앙', '한대앞', '상록수', '반월', '대야미', '수리산']
        # 4호선 기준. 노선도의 각 면 별로 역들 정리

        now_station = '산본'
        now_stationNum = -1
        for i in range(len(line4)):
            if now_station == line4[i]:
                now_stationNum = i  # line2, 즉 역들 리스트 안에 now_station이 있을 경우 해당 인덱스를 now_stationNum에 저장
                # 리스트 내에 없을 경우, now_stationNum은 그대로 -1이고 노선도에 표시가 안 됨

        global x  # draw_Lines에서도 x 쓸 거라서.. 일단 전역변수 해놓음
        x = 10

        # qp.drawRect(x좌표, y좌표, 포인트의 크기(x, y) => 포인트 생성
        # int() 넣는 이유: 실수형으로 넣을 경우 경고문이 떠서
        if 0 <= now_stationNum < 11:
            qp.drawRect(int(8 + 3.25 * now_stationNum) * x, int(9.5 * x), 12, 12)
        elif 11 <= now_stationNum < 23:
            qp.drawRect(int(8 + 2.95 * (now_stationNum - 11)) * x, int(19.5 * x), 12, 12)
        elif 23 <= now_stationNum < 36:
            qp.drawRect(int(8 + 2.8 * (now_stationNum - 23)) * x, int(29.5 * x), 12, 12)
        elif 36 <= now_stationNum <= 48:
            qp.drawRect(int(8 + 2.95 * (now_stationNum - 36)) * x, int(39.5 * x), 12, 12)

        # print(now_stationNum)

    def draw_Lines(self, qp):  # 3호선
        darkCyan = Qt.darkCyan
        linePen = QPen(darkCyan, 3.5, Qt.SolidLine)
        qp.setPen(linePen)

        x = 10  # 크기조정하면 위치가 이상해짐.....수정필요
        qp.drawLine(6 * x, 10 * x, 44 * x, 10 * x)  # x1, y1, x2, y2  # 1행
        qp.drawLine(6 * x, 20 * x, 44 * x, 20 * x)  # 2행    # 가로 길이 = 38 * x
        qp.drawLine(6 * x, 30 * x, 44 * x, 30 * x)  # 3행
        qp.drawLine(6 * x, 40 * x, 44 * x, 40 * x)  # 4행
        qp.drawLine(44 * x, 10 * x, 44 * x, 20 * x)  # 1열    # 세로 길이 = 10 * x
        qp.drawLine(6 * x, 20 * x, 6 * x, 30 * x)  # 2열
        qp.drawLine(44 * x, 30 * x, 44 * x, 40 * x)  # 3열

# def timeout_run(self):
    #     if self.pos_x < 0 or self.pos_x > self.width() - 8:
    #         self.direction *= -1
    #     self.pos_x = self.pos_x + (self.direction * self.speed)
    #     # print(self.pos_x, self.width())
    #     self.update()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())